import { aiTab } from "./aiTab";
import { chillTab } from "./chillTabs";
import { mainTab } from "./mainTab";

export const myTabs = [mainTab, aiTab, chillTab];
