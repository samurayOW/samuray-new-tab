export const location = "Zadunaivka";
